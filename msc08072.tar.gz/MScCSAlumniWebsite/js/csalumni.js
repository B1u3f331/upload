 /*---------------------------------------------- 
                       To Top
 ------------------------------------------------*/
$(window).scroll(function () {
    if ($(this).scrollTop() >= 100) {
        $("#toTop").fadeIn();
    } else {
        $("#toTop").fadeOut();
    }
});

$("#toTop").click(function () {
    $("body,html").animate({ scrollTop: 0 }, 10e2);
});


$(document).ready(function () {
    $('[data-toggle="popover"]').popover({
        //trigger: 'focus',
        trigger: 'hover',
        html: true,
        content: function () {
            return '<img class="img-fluid" src="' + $(this).data('img') + '" />';
        },
        title: 'Toolbox'
    })
});

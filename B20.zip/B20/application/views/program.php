
<html>
<head>
    <title></title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href=<?php echo base_url("assets/css/main.css");?> />

    <!-- Bootstrap core CSS -->
    <link href=<?php echo base_url("dist/css/bootstrap.min.css");?> rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href=<?php echo base_url("assets/offcanvas.css");?> rel="stylesheet">

    <noscript><link rel="stylesheet" href=<?php echo base_url("assets/css/noscript.css");?> /></noscript>
</head>
<body class="is-preload landing">
<div id="page-wrapper">
    <!-- Header -->
    <header id="header">
        <h1 id="logo"><a href="index.html">Dark Lab </a></h1>
        <nav id="nav">
            <ul>
                <li><a href="index.html">Home</a></li>
                <li>
                    <a href="#">Business</a>
                    <ul>
                        <li><a href="left-sidebar.html">Request Demo</a></li>
                        <li><a href="right-sidebar.html">Red Teaming Simulation</a></li>
                        <li>
                            <a href="#">Submenu</a>
                            <ul>
                                <li><a href="#">Option 1</a></li>
                                <li><a href="#">Option 2</a></li>
                                <li><a href="#">Option 3</a></li>
                                <li><a href="#">Option 4</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="elements.html">About</a></li>
                <li><a href="#" class="button primary">Logout</a></li>
            </ul>
        </nav>
    </header>
</div>

    <!-- Banner -->
    <section id="banner">
        <div class="content">




<main role="main" class="container">
    <div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded box-shadow">
        <img class="mr-3" src="<?php echo base_url("images/bug.jpg");?>" alt="" width="48" height="48">
        <div class="lh-100">
            <h6 class="mb-0 text-white lh-100">Bug bounty Programs</h6>
            <small>Since 2020</small>
        </div>
    </div>

    <div class="my-3 p-3 bg-white rounded box-shadow">
        <h6 class="border-bottom border-gray pb-2 mb-0">Recent updates</h6>
        <div class="media text-muted pt-3">
            <img data-src="holder.js/32x32?theme=thumb&bg=007bff&fg=007bff&size=1" alt="" class="mr-2 rounded">
            <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
                <strong class="d-block text-gray-dark">@username</strong>
                Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.
            </p>
        </div>
        <div class="media text-muted pt-3">
            <img data-src="holder.js/32x32?theme=thumb&bg=e83e8c&fg=e83e8c&size=1" alt="" class="mr-2 rounded">
            <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
                <strong class="d-block text-gray-dark">@username</strong>
                Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.
            </p>
        </div>
        <div class="media text-muted pt-3">
            <img data-src="holder.js/32x32?theme=thumb&bg=6f42c1&fg=6f42c1&size=1" alt="" class="mr-2 rounded">
            <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
                <strong class="d-block text-gray-dark">@username</strong>
                Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.
            </p>
        </div>
        <small class="d-block text-right mt-3">
            <a href="#">All updates</a>
        </small>
    </div>


</main>
        </div>
    </section>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script>window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
<script src=<?php echo base_url("assets/js/vendor/popper.min.js");?>></script>
<script src=<?php echo base_url("dist/js/bootstrap.min.js");?>></script>
<script src=<?php echo base_url("assets/js/vendor/holder.min.js");?>></script>
<script src=<?php echo base_url("assets/offcanvas.js");?>></script>
    <!-- Main JS-->
    <script src="js/global.js"></script>
</body>
</html>
<script src=<?php echo base_url("assets/js/jquery.min.js");?>></script>
<script src=<?php echo base_url("assets/js/jquery.scrolly.min.js");?>></script>
<script src=<?php echo base_url("assets/js/jquery.dropotron.min.js");?>></script>
<script src=<?php echo base_url("assets/js/jquery.scrollex.min.js");?>></script>
<script src=<?php echo base_url("assets/js/browser.min.js");?>></script>
<script src=<?php echo base_url("assets/js/breakpoints.min.js");?>></script>
<script src=<?php echo base_url("assets/js/util.js");?>></script>
<script src=<?php echo base_url("assets/js/main.js");?>></script>
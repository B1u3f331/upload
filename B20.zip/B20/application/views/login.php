
<html>
<head>
    <title></title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href=<?php echo base_url("assets/css/main.css");?> />
    <link rel="stylesheet" href=<?php echo base_url("css/main.css");?> />
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <noscript><link rel="stylesheet" href=<?php echo base_url("assets/css/noscript.css");?> /></noscript>
</head>
<body class="is-preload landing">
<div id="page-wrapper">
    <!-- Header -->
    <header id="header">
        <h1 id="logo"><a href="index.html">Dark Lab </a></h1>
        <nav id="nav">
            <ul>
                <li><a href="index.html">Home</a></li>
                <li>
                    <a href="#">Business</a>
                    <ul>
                        <li><a href="left-sidebar.html">Request Demo</a></li>
                        <li><a href="right-sidebar.html">Red Teaming Simulation</a></li>
                        <li>
                            <a href="#">Submenu</a>
                            <ul>
                                <li><a href="#">Option 1</a></li>
                                <li><a href="#">Option 2</a></li>
                                <li><a href="#">Option 3</a></li>
                                <li><a href="#">Option 4</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="elements.html">About</a></li>
                <li><a href="#" class="button primary">Start Hacking</a></li>
            </ul>
        </nav>
    </header>

    <!-- Banner -->
    <div class="alert alert-danger">
            <div class="page-wrapper bg-gra-01 p-t-180 p-b-100 font-poppins">
                <div class="wrapper wrapper--w780">
                    <div class="card card-3">
                        <div class="card-heading"></div>
                        <div class="card-body">
                            <h2 class="title">Researcher Portal</h2>
                            <form method="POST" action="<?php echo base_url("index.php/user/login");?>">

                                <div class="input-group">
                                    <input class="input--style-3" type="text" placeholder="username" name="username">
                                </div>
                                <div class="input-group">
                                    <input class="input--style-3" type="password" placeholder="password" name="password">
                                </div>
                                <div class="p-t-10">
                                    <button class="btn btn--pill btn--green" type="submit">login</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


        </div>
    </section>
</div>
<!-- Jquery JS-->

<!-- Vendor JS-->
<script src="vendor/select2/select2.min.js"></script>
<script src="vendor/datepicker/moment.min.js"></script>
<script src="vendor/datepicker/daterangepicker.js"></script>

<!-- Main JS-->
<script src="js/global.js"></script>
</body>
</html>
<script src=<?php echo base_url("assets/js/jquery.min.js");?>></script>
<script src=<?php echo base_url("assets/js/jquery.scrolly.min.js");?>></script>
<script src=<?php echo base_url("assets/js/jquery.dropotron.min.js");?>></script>
<script src=<?php echo base_url("assets/js/jquery.scrollex.min.js");?>></script>
<script src=<?php echo base_url("assets/js/browser.min.js");?>></script>
<script src=<?php echo base_url("assets/js/breakpoints.min.js");?>></script>
<script src=<?php echo base_url("assets/js/util.js");?>></script>
<script src=<?php echo base_url("assets/js/main.js");?>></script>
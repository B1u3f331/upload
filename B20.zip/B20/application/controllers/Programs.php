<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Programs extends Auth_Controller {


    public function index()
    {
        $this->load->view('program');
    }
}
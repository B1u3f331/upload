<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('ion_auth');
        $this->load->model('ion_auth_model');
      //  $this->load->library('postal');
    }

    public function index()
    {
        if($this->ion_auth->logged_in()===FALSE)
        {
           redirect('user/login');

        }
        redirect('dashboard');
    }

    public function login()
    {
        $this->data['title'] = "Login";

        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        $this->form_validation->set_rules('ajax','AJAX','trim|is_natural');
        if ($this->form_validation->run() === FALSE)
        {
            if($this->input->post('ajax'))
            {
                $response['username_error'] = form_error('username');
                $response['password_error'] = form_error('password');
                header("content-type:application/json");
                echo json_encode($response);
                exit;
            }
            $this->load->helper('form');

            $this->render('login');
        }
        else
        {
            $remember = (bool) $this->input->post('remember');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
         //   $token=  $this->security->get_csrf_hash();
            $this->ion_auth->set_hook('post_login_successful', 'get_gravatar_hash', $this, '_gravatar', array());

            if ($this->ion_auth->login($username, $password, $remember))
            {
                if($this->input->post('ajax'))
                {
                    $response['logged_in'] = 1;
                    header("content-type:application/json");
                    echo json_encode($response);
                    exit;
                }
                $this->load->library('rat');
                $this->rat->log('User logged in',1);
                redirect('index.php/programs');
            }
            else
            {
                if($this->input->post('ajax'))
                {

                    $response['username'] = $username;
                    $response['password'] = $password;
                    $response['error'] = $this->ion_auth->errors();
                    header("content-type:application/json");
                    echo json_encode($response);

                    exit;
                }
                echo $result='<div class="alert alert-danger">Wrong Credentials !</div>';
                $_SESSION['auth_message'] = $this->ion_auth->errors();
                $this->session->mark_as_flash('auth_message');
                $this->render('login');
            //  redirect('user/login');

            }
        }
    }

    public function forgot()
    {
        $this->data['title'] = "Forgot email";
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        if($this->form_validation->run() === FALSE)
        {
            $this->render('user/forgot_view');
        }
        else
        {
            $username = $this->input->post('username');
            $forgotten=$this->ion_auth->forgotten_password($username);
            if($forgotten) {
                $this->session->mark_as_flash('auth_message');
                redirect('user/login');
            } else {
                redirect('user/login');
            }
        }

    }

    public function _gravatar()
    {
        if($this->form_validation->valid_email($_SESSION['email']))
        {
            $gravatar_url = md5(strtolower(trim($_SESSION['email'])));
            $_SESSION['gravatar'] = $gravatar_url;
        }
        return TRUE;
    }
public  function register()
{
    $this->load->library('postal');
    $this->load->library('form_validation');
    $this->form_validation->set_rules('name','First name','trim');
    $this->form_validation->set_rules('username','Username','trim|required');
    $this->form_validation->set_rules('email','Email','trim|required|valid_email');
    $this->form_validation->set_rules('password','Password','required|min_length[6]');
    if($this->form_validation->run()===FALSE)
    {
        echo "please make sure submit correct information " .$_SERVER['REMOTE_ADDR'];
    }else{
        $username = $this->input->post('username');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $group_ids=[2];
        $additional_data = array(
            'first_name' => $this->input->post('first_name'),
            'last_name'  => $this->input->post('last_name')

        );
        $query = $this->db->get_where('users', array('email' => $email));    // this responsible for validation if account email is already existed
        if ($query->num_rows() > 0) {

           echo  $result='<div class="alert alert-danger">Email is Already registered!</div>';
         //   redirect('welcome');
           echo $this->postal->add($result, 'success');
             $this->render('signup');
           // redirect('welcome/signup');

        }else {
            $this->ion_auth->register($username, $password, $email, $additional_data,$group_ids);
            $this->postal->add($this->ion_auth->messages(), 'success');
            redirect('index.php/login');
        }

    }
}
    public function logout()
    {
        $this->load->library('rat');
        $this->rat->log('User logged out',1);
        $this->ion_auth->logout();
        redirect('user/login');
    }
}